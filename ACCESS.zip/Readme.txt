Mod name: ACCESS
Author: Stalwart Pachyderm
Version: 0.9
Avorion v: 0.15.7 

This mod aims to enable users to easily modify the spawning of asteroids in thier games. By default, the mod is set to Avorion defaults for asteroid generation. By tweaking the values in the top of the file you can control the size of all types of spawned asteroids, including per material type, density of asteroid fields, and size of claimable asteroids. These values have been convieniently grouped to allow easy editing of the spawning of asteroids. 